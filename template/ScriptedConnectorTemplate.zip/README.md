# Scripted Connector Template

This template provides a starting point for creating Scripted Connectors. Scripted connectors are distributed as `.dmscript` packages, which are structured archives containing metadata, source code, and platform-specific dependencies required to execute the connector.

## Getting Started

To create your own connector from this template:

1. **Update the Manifest**: Edit `manifest.json` and generate a new UUID for `project.id` (you can use an online generator like [guidgenerator.com](https://www.guidgenerator.com/)). Update the `project.name`, `project.author`, and `project.description`.
2. **Write your Code**: Place your Python scripts in the `run/` directory. By default, `run/main.py` is configured as the entry point.
3. **Add Dependencies**: The scripted connector runtime has the Python standard library and pip installed by default. Any other dependencies you use must exist as a Wheel (`.whl`) for the platform you are developing for, so they can be included in the scripted connector packaging later on. Use the [Python scripted connector wheels resolver tool](https://github.com/SkylineCommunications/edge-node-scripted-connectors-kit/tree/master/wheels-resolver) in `resolve` mode to easily check for which platforms a dependency has wheels available. When you are ready to package everything, use the tool in `download` mode to get all the dependencies.
4. **Package**: To prepare for deployment, create the final archive. Zip the contents of this folder (not the folder itself, making sure `manifest.json`, `README.md`, `run`, and `dependencies` are at the root of the ZIP file) to produce the final scripted connector package. Change the extension from `.zip` to `.dmscript`.

## Package Structure

Your connector should follow this directory layout before packaging:

```text
MyScriptedConnector/
├── manifest.json
├── README.md
├── run/
│   ├── main.py
│   └── ...
└── dependencies/
    ├── x86_64-windows-msvc/
    │   └── package1.whl
    ├── x86_64-linux-gnu/
    │   └── package2.whl
    └── universal/
        └── package3.whl
```

## Manifest Details

The `manifest.json` file defines the connector metadata, runtime requirements, and execution configuration. Currently, only Python is supported.

Key fields:
- `project.id`: Globally unique identifier (GUID).
- `project.name` / `project.version`: Connector identity and semantic version.
- `runtime.language`: Must be `"python"`.
- `runtime.supported_platforms`: Supported platforms (e.g., `["x86_64-windows-msvc", "x86_64-linux-gnu"]`).
- `runtime.python.version`: Example `>=3.14;<3.15`.
- `runtime.python.entry_point`: The relative path to the main script (e.g., `"run/main.py"`).

> Note: For any Python constraints, use exact versions (`==`) or boundaries (e.g. `>=3.10;<3.11`).
