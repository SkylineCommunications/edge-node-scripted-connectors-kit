import argparse
import requests

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runSecret", required=True)
    args = parser.parse_args()

    run_secret = args.runSecret

    data = {
        # ... your collected data
    }

    headers = {
        "identifier": "<your-identifier>",
        "type": "<your-type>",
        "runSecret": run_secret,
    }

    requests.post("http://localhost:5016/api/data", json=data, headers=headers)

if __name__ == "__main__":
    main()
